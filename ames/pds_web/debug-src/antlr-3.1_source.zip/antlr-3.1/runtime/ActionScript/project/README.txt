This directory contains the source files required to build the runtime and the associated tests.

Running Unit Tests
==================
The unit tests can be run using the ant "test" target.  The tests use flexUnit and the flexUnit ant integration provided by Peter Martin.
FlexUnit is available at:

http://code.google.com/p/as3flexunitlib/

The latest ant integration from Peter Martin can be found on his blog:

http://weblogs.macromedia.com/pmartin/archives/2007/09/flexunit_for_an_2.cfm


