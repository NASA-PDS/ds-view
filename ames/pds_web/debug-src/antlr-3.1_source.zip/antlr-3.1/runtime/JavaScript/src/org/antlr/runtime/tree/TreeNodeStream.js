/** A stream of tree nodes, accessing nodes from a tree of some kind */
org.antlr.runtime.tree.TreeNodeStream = function() {};
